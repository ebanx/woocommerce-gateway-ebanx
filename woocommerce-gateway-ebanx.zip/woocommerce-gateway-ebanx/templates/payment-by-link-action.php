<li class="wide">
	<input
		type="submit"
		class="button save_order button-primary tips"
		name="create_ebanx_payment_link"
		value="<?php _e('Create EBANX Payment Link', 'woocommerce-gateway-ebanx'); ?>"
		data-tip="<?php _e('The order will be created on your site and also sent to EBANX to generate a payment to your customer pay directly.', 'woocommerce-gateway-ebanx'); ?>"
	/>
</li>

<?php
/**
 * Baloto - Checkout form.
 *
 * @author  EBANX.com
 * @package WooCommerce_EBANX/Templates
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div id="ebanx-baloto-payment" class="ebanx-payment-container ebanx-language-es"></div>
